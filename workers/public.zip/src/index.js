export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const searchParams = url.searchParams;

    // 变量替换器，支持 $[Product.Name] 等嵌套字段
    const render = (template, data) =>
      template.replace(/\$\[([A-Za-z0-9_\.]+)\]/g, (_, key) => {
        const keys = key.split(".");
        return keys.reduce((obj, k) => obj?.[k], data) ?? "";
      });

    // 从 Assets 获取 HTML/CSS 模板
    async function getTemplate(filename) {
      return await env.ASSETS.get(filename);
    }

    // 查询数据库
    async function query(sql, bindings = []) {
      const stmt = env.DB.prepare(sql);
      const res = bindings.length ? await stmt.bind(...bindings).all() : await stmt.all();
      return res.results || [];
    }

    // ✅ 处理静态资源
    if (path === "/style.css") {
      const css = await getTemplate("style.css");
      return new Response(css, { headers: { "content-type": "text/css" } });
    }

    if (path === "/" || path === "/index") {
      const html = await getTemplate("index.html");
      const top3 = await query("SELECT * FROM Products ORDER BY Sales DESC LIMIT 3");

      const data = {
        ProductA: top3[0] || {},
        ProductB: top3[1] || {},
        ProductC: top3[2] || {}
      };

      return new Response(render(html, data), {
        headers: { "content-type": "text/html; charset=UTF-8" }
      });
    }

    if (path === "/products") {
      const html = await getTemplate("products.html");
      const products = await query("SELECT * FROM Products");
      return new Response(render(html, {
        Products: { List: products }
      }), {
        headers: { "content-type": "text/html; charset=UTF-8" }
      });
    }

    if (path === "/detail") {
      const pid = searchParams.get("Pid");
      if (!pid) return new Response("Missing Pid", { status: 400 });

      const html = await getTemplate("detail.html");
      const product = (await query("SELECT * FROM Products WHERE Pid = ?", [pid]))[0];
      return new Response(render(html, {
        Product: product || {}
      }), {
        headers: { "content-type": "text/html; charset=UTF-8" }
      });
    }

    if (path === "/cart") {
      const uid = searchParams.get("Uid");
      if (!uid) return new Response("Missing Uid", { status: 400 });

      const html = await getTemplate("cart.html");
      const user = (await query("SELECT * FROM Users WHERE Uid = ?", [uid]))[0];
      let cartItems = [];

      try {
        cartItems = user?.Cart ? JSON.parse(user.Cart) : [];
      } catch (e) {
        cartItems = [];
      }

      return new Response(render(html, {
        CartItems: { List: cartItems }
      }), {
        headers: { "content-type": "text/html; charset=UTF-8" }
      });
    }

    if (path === "/comment") {
      const pid = searchParams.get("Pid");
      if (!pid) return new Response("Missing Pid", { status: 400 });

      const html = await getTemplate("comment.html");
      const rows = await query("SELECT Comment FROM Comments WHERE Pid = ?", [pid]);
      const comments = rows.map(row => row.Comment);

      return new Response(render(html, {
        Comments: { List: comments }
      }), {
        headers: { "content-type": "text/html; charset=UTF-8" }
      });
    }

    if (path === "/login") {
      const html = await getTemplate("login.html");
      return new Response(html, {
        headers: { "content-type": "text/html; charset=UTF-8" }
      });
    }

    // ✅ 可选 API：添加评论
    if (request.method === "POST" && path === "/api/add_comment") {
      const pid = searchParams.get("Pid");
      if (!pid) return new Response("Missing Pid", { status: 400 });

      const { comment } = await request.json();
      if (!comment) return new Response("Missing comment", { status: 400 });

      await query("INSERT INTO Comments (Pid, Comment) VALUES (?, ?)", [pid, comment]);
      return new Response("OK", { status: 200 });
    }

    return new Response("404 Not Found", { status: 404 });
  }
};
